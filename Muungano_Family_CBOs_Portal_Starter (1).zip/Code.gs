/** MUUNGANO FAMILY CBOs - Google Apps Script starter backend.
 * Setup: create a spreadsheet, paste its ID into SPREADSHEET_ID below,
 * then deploy as Web App. Restrict access appropriately before real use.
 */
const SPREADSHEET_ID = 'PASTE_GOOGLE_SHEET_ID_HERE';
const SHEETS = {
 Members:['MemberID','FullName','Sex','DateOfBirth','UNHCRID','Phone','Location','FamilySize','Orphans','Widows','JoinDate','Status','Notes','CreatedAt','UpdatedAt'],
 Business_Funds:['RecordID','FullName','UNHCRID','MemberID','Location','BusinessType','Amount','DateReceived','UseNotes','ApprovedBy','PaymentRef','CreatedAt','UpdatedAt'],
 Monthly_Savings:['RecordID','FullName','MemberID','Month','Year','BaseAmount','Rate','RequiredAmount','PaidAmount','Balance','PaymentDate','Status','Notes','CreatedAt','UpdatedAt'],
 Participation:['RecordID','ActivityDate','ActivityName','Purpose','FullName','UNHCRID','MemberID','Location','Phone','CheckIn','CheckOut','Supervisor','Notes','CreatedAt','UpdatedAt'],
 Gifts:['RecordID','GiftDate','Purpose','FullName','Sex','UNHCRID','MemberID','MpesaNumber','Amount','Location','ApprovedBy','Notes','CreatedAt','UpdatedAt'],
 Management_Teams:['RecordID','FullName','MemberID','UNHCRID','Sex','Phone','Location','Position','StartDate','EndDate','Status','Notes','CreatedAt','UpdatedAt'],
 Beneficiaries:['RecordID','FullName','DateOfBirth','Sex','Phone','UNHCRID','Location','SupportType','SupportDate','Amount','Status','Notes','CreatedAt','UpdatedAt'],
 Home_Visits:['VisitID','VisitDate','FullName','Sex','FamilySize','Phone','UNHCRID','Location','Purpose','FamilySituation','Needs','ActionsTaken','Officer','NextVisitDate','NextPurpose','Status','CreatedAt','UpdatedAt'],
 Activity_Reports:['ReportID','Title','Department','Author','Position','ActivityDate','Location','Purpose','Activities','Participants','Results','Challenges','Expenses','Recommendations','NextSteps','ApprovalStatus','CreatedAt','UpdatedAt'],
 Admin_Users:['Email','FullName','Role','Active'], Audit_Log:['Timestamp','Email','Action','Sheet','RecordID'], Settings:['Key','Value']
};
function doGet(){return json_({ok:true,data:{message:'Muungano API iko tayari',version:'1.0'}})}
function doPost(e){try{const req=JSON.parse((e.postData&&e.postData.contents)||'{}');const action=req.action; if(action==='ping')return json_({ok:true,data:{message:'pong'}});if(action==='getAll'){const all={};Object.keys(SHEETS).forEach(n=>{if(!['Admin_Users','Audit_Log','Settings'].includes(n))all[n]=read_(n)});return json_({ok:true,data:all})}if(action==='create'||action==='update'){const sheet=req.sheet,record=req.record;if(!SHEETS[sheet]||!record)throw new Error('Sheet au rekodi si sahihi');const result=save_(sheet,record,action==='update',req.id);audit_(action,sheet,req.id||record.ID||'');return json_({ok:true,data:result})}throw new Error('Kitendo hakijulikani');}catch(err){return json_({ok:false,error:String(err.message||err)})}}
function ss_(){if(SPREADSHEET_ID==='PASTE_GOOGLE_SHEET_ID_HERE')throw new Error('Weka SPREADSHEET_ID ndani ya Code.gs kwanza');return SpreadsheetApp.openById(SPREADSHEET_ID)}
function setupSheets(){const ss=ss_();Object.keys(SHEETS).forEach(name=>{let sh=ss.getSheetByName(name)||ss.insertSheet(name);if(sh.getLastRow()===0)sh.appendRow(SHEETS[name]);});return 'Sheets zote zimetengenezwa.'}
function read_(name){const sh=ss_().getSheetByName(name);if(!sh)return [];const v=sh.getDataRange().getValues();if(v.length<2)return [];const h=v[0].map(String);return v.slice(1).filter(r=>r.some(x=>x!==''&&x!==null)).map(r=>{const o={};h.forEach((k,i)=>o[k]=r[i] instanceof Date?Utilities.formatDate(r[i],Session.getScriptTimeZone(),'yyyy-MM-dd'):r[i]);return o})}
function save_(name,obj,isUpdate,id){const sh=ss_().getSheetByName(name);if(!sh)throw new Error('Sheet haipo. Endesha setupSheets()');const headers=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0].map(String);const key=headers[0];const values=sh.getDataRange().getValues();let row=-1;if(isUpdate&&id){for(let i=1;i<values.length;i++){if(String(values[i][0])===String(id)){row=i+1;break}}if(row<0)throw new Error('Rekodi ya kuhariri haijapatikana')}if(!isUpdate){if(obj.UNHCRID&&name==='Members'&&read_(name).some(r=>String(r.UNHCRID)===String(obj.UNHCRID)))throw new Error('UNHCR ID hii tayari imesajiliwa');if(obj[key]&&read_(name).some(r=>String(r[key])===String(obj[key])))throw new Error('ID hii tayari ipo')}const line=headers.map(h=>obj[h]===undefined?'':obj[h]);if(row>0)sh.getRange(row,1,1,headers.length).setValues([line]);else sh.appendRow(line);return obj}
function audit_(action,sheet,id){try{const email=Session.getActiveUser().getEmail()||'unknown';ss_().getSheetByName('Audit_Log').appendRow([new Date(),email,action,sheet,id])}catch(e){}}
function json_(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON)}
